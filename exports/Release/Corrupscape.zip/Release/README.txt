Hello!

Ika here.

Thank you for downloading Corrupscape!

It's not the best game, it isn't coded very well or anything...

But it's playable!



This game was made for the Pirate Software Game Jam of 1/20/2024.

If you downloaded this game from anywhere BUT itch.io (or from Ika directly), you might be downloading a modified file!



welp, i feel fufilled.
also, there is no secret ending, trust me.
at least not for this build. there was gonna be one but i just really wanna get this version out right now

anyways, thank you and have fun!